<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="henry_0_mirror" tilewidth="80" tileheight="80" tilecount="70" columns="10">
 <image source="henry_0_mirror.png" width="800" height="560"/>
</tileset>
